# Blue Suede Website

Welcome to the **Blue Suede** website repository!  
Blue Suede is a curated café, wine bar, and cultural hub based in El Salvador. Experience analog sound, natural wine, and contemporary culture.

This repository contains the source code for the Blue Suede landing page, which highlights our concept, offerings, and contact information.

## 🌐 Live Demo

Once published with GitHub Pages, visit:  
`https://bluesuede.github.io/blue-suede-website/`

## 📄 About

Blue Suede isn’t just a place—it’s a lifestyle. Sip artisan wine, savor soulful cuisine, and groove to carefully curated vinyl sounds. Nestled in El Salvador, our space invites you to slow down and celebrate the beauty of taste, sound, and connection.

## ✨ Features

- Responsive single-page website
- Modern, chic design
- Sectioned navigation (Home, About, Contact)

